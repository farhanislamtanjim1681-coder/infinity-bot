Replit > Secrets > New Secret
Key: BOT_TOKEN
Value: আপনার BotFather টোকেন
