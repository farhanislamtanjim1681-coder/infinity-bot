import os
from telegram import Update
from telegram.ext import Application, MessageHandler, ContextTypes, filters

TOKEN = os.getenv("BOT_TOKEN")

SCAM_WORDS = [
    "t.me/", "bit.ly", "tinyurl.com",
    "wa.me", "free money", "airdrop", "earn $"
]

async def welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for user in update.message.new_chat_members:
        await update.message.reply_text(
            f"👋 স্বাগতম {user.first_name}!\n🌸 আপনি কেমন আছেন? আমাদের গ্রুপে আপনাকে স্বাগতম!"
        )

async def anti_scam(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower() if update.message.text else ""
    if any(word in text for word in SCAM_WORDS):
        try:
            await update.message.delete()
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text="🚫 Scam/সন্দেহজনক লিংক ডিলিট করা হয়েছে।"
            )
        except:
            pass

app = Application.builder().token(TOKEN).build()
app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, anti_scam))

print("Bot Running...")
app.run_polling()
